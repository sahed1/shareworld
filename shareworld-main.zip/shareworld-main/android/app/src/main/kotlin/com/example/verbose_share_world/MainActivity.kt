package com.flutter.share_world

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
